import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { User, Award, TrendingUp, Gift, Zap, Target, Trophy } from 'lucide-react-native';
import { StatsCard } from '@/components/StatsCard';
import { AchievementBadge } from '@/components/AchievementBadge';
import { DailyTip } from '@/components/DailyTip';
import { ProgressCircle } from '@/components/ProgressCircle';

export default function Dashboard() {
  const user = {
    name: 'Alex Chen',
    avatar: '👨‍💻',
    rank: 23,
    totalKg: 45.8,
    totalItems: 127,
    localRank: 3,
    location: 'San Francisco',
    monthlyGoal: 50,
    currentMonth: 12.4,
  };

  const achievements = [
    { id: 1, name: 'First Drop', icon: '🎯', unlocked: true },
    { id: 2, name: 'Green Warrior', icon: '🌿', unlocked: true },
    { id: 3, name: 'E-Waste Hero', icon: '⚡', unlocked: false },
    { id: 4, name: 'Top Contributor', icon: '👑', unlocked: false },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.userInfo}>
            <View style={styles.avatar}>
              <Text style={styles.avatarEmoji}>{user.avatar}</Text>
            </View>
            <View style={styles.userDetails}>
              <Text style={styles.userName}>Hi, {user.name}!</Text>
              <Text style={styles.userLocation}>{user.location}</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.notificationButton}>
            <Zap size={24} color="#22C55E" />
          </TouchableOpacity>
        </View>

        {/* Monthly Progress */}
        <View style={styles.progressSection}>
          <Text style={styles.sectionTitle}>Monthly Goal Progress</Text>
          <View style={styles.progressContainer}>
            <ProgressCircle 
              progress={user.currentMonth / user.monthlyGoal} 
              size={120}
              strokeWidth={8}
              color="#22C55E"
            />
            <View style={styles.progressInfo}>
              <Text style={styles.progressText}>
                <Text style={styles.progressCurrent}>{user.currentMonth} kg</Text> / {user.monthlyGoal} kg
              </Text>
              <Text style={styles.progressSubtext}>Keep it up! You're doing great</Text>
              <TouchableOpacity style={styles.goalButton}>
                <Target size={16} color="#22C55E" />
                <Text style={styles.goalButtonText}>Adjust Goal</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>Your Impact</Text>
          <View style={styles.statsGrid}>
            <StatsCard
              title="Global Rank"
              value={`#${user.rank}`}
              subtitle="out of 10,247 users"
              icon={<Trophy size={24} color="#22C55E" />}
              trend="+2"
            />
            <StatsCard
              title="Local Rank"
              value={`#${user.localRank}`}
              subtitle={`in ${user.location}`}
              icon={<Award size={24} color="#10B981" />}
              trend="+1"
            />
          </View>
          <View style={styles.statsGrid}>
            <StatsCard
              title="Total Weight"
              value={`${user.totalKg} kg`}
              subtitle="e-waste recycled"
              icon={<TrendingUp size={24} color="#059669" />}
              trend="+3.2kg"
            />
            <StatsCard
              title="Items Recycled"
              value={user.totalItems.toString()}
              subtitle="devices saved"
              icon={<Gift size={24} color="#047857" />}
              trend="+12"
            />
          </View>
        </View>

        {/* Achievements */}
        <View style={styles.achievementsSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Achievements</Text>
            <TouchableOpacity>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.achievementsList}>
            {achievements.map((achievement) => (
              <AchievementBadge
                key={achievement.id}
                name={achievement.name}
                icon={achievement.icon}
                unlocked={achievement.unlocked}
              />
            ))}
          </ScrollView>
        </View>

        {/* Daily Tip */}
        <DailyTip />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scrollContent: {
    paddingBottom: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E0F2FE',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  avatarEmoji: {
    fontSize: 24,
  },
  userDetails: {},
  userName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  userLocation: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  notificationButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  progressSection: {
    marginHorizontal: 20,
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  progressContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  progressInfo: {
    flex: 1,
    marginLeft: 24,
  },
  progressText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
    marginBottom: 4,
  },
  progressCurrent: {
    color: '#22C55E',
    fontFamily: 'Inter-Bold',
  },
  progressSubtext: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 12,
  },
  goalButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#F0FDF4',
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  goalButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#22C55E',
    marginLeft: 4,
  },
  statsSection: {
    marginHorizontal: 20,
    marginBottom: 32,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  achievementsSection: {
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  viewAllText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#22C55E',
  },
  achievementsList: {
    paddingHorizontal: 20,
    gap: 12,
  },
});