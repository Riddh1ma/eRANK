import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Trophy, Medal, Award, TrendingUp, Globe, MapPin } from 'lucide-react-native';
import { LeaderboardCard } from '@/components/LeaderboardCard';
import { useState } from 'react';

export default function Leaderboard() {
  const [activeTab, setActiveTab] = useState<'global' | 'local'>('global');

  const globalLeaders = [
    { id: 1, name: 'Maria Rodriguez', avatar: '👩‍💼', kg: 156.7, items: 421, rank: 1, location: 'Madrid' },
    { id: 2, name: 'David Kim', avatar: '👨‍🎓', kg: 142.3, items: 389, rank: 2, location: 'Seoul' },
    { id: 3, name: 'Sarah Johnson', avatar: '👩‍🔬', kg: 138.9, items: 367, rank: 3, location: 'Boston' },
    { id: 4, name: 'Alex Chen', avatar: '👨‍💻', kg: 45.8, items: 127, rank: 23, location: 'San Francisco', isCurrentUser: true },
  ];

  const localLeaders = [
    { id: 1, name: 'Jennifer Wu', avatar: '👩‍⚕️', kg: 87.2, items: 234, rank: 1, location: 'San Francisco' },
    { id: 2, name: 'Michael Brown', avatar: '👨‍🏫', kg: 72.4, items: 198, rank: 2, location: 'San Francisco' },
    { id: 3, name: 'Alex Chen', avatar: '👨‍💻', kg: 45.8, items: 127, rank: 3, location: 'San Francisco', isCurrentUser: true },
    { id: 4, name: 'Lisa Park', avatar: '👩‍🎨', kg: 41.2, items: 115, rank: 4, location: 'San Francisco' },
  ];

  const currentLeaders = activeTab === 'global' ? globalLeaders : localLeaders;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Leaderboard</Text>
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'global' && styles.activeTab]}
            onPress={() => setActiveTab('global')}
          >
            <Globe size={16} color={activeTab === 'global' ? '#FFFFFF' : '#6B7280'} />
            <Text style={[styles.tabText, activeTab === 'global' && styles.activeTabText]}>
              Global
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'local' && styles.activeTab]}
            onPress={() => setActiveTab('local')}
          >
            <MapPin size={16} color={activeTab === 'local' ? '#FFFFFF' : '#6B7280'} />
            <Text style={[styles.tabText, activeTab === 'local' && styles.activeTabText]}>
              San Francisco
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Top 3 Podium */}
        <View style={styles.podiumSection}>
          <View style={styles.podium}>
            {/* Second Place */}
            <View style={styles.podiumPlace}>
              <View style={[styles.podiumAvatar, styles.secondPlace]}>
                <Text style={styles.podiumAvatarText}>{currentLeaders[1]?.avatar}</Text>
              </View>
              <View style={[styles.podiumBar, styles.secondBar]} />
              <Text style={styles.podiumRank}>2</Text>
              <Text style={styles.podiumName}>{currentLeaders[1]?.name.split(' ')[0]}</Text>
              <Text style={styles.podiumKg}>{currentLeaders[1]?.kg} kg</Text>
            </View>

            {/* First Place */}
            <View style={styles.podiumPlace}>
              <View style={styles.crownContainer}>
                <Trophy size={20} color="#FFD700" />
              </View>
              <View style={[styles.podiumAvatar, styles.firstPlace]}>
                <Text style={styles.podiumAvatarText}>{currentLeaders[0]?.avatar}</Text>
              </View>
              <View style={[styles.podiumBar, styles.firstBar]} />
              <Text style={styles.podiumRank}>1</Text>
              <Text style={styles.podiumName}>{currentLeaders[0]?.name.split(' ')[0]}</Text>
              <Text style={styles.podiumKg}>{currentLeaders[0]?.kg} kg</Text>
            </View>

            {/* Third Place */}
            <View style={styles.podiumPlace}>
              <View style={[styles.podiumAvatar, styles.thirdPlace]}>
                <Text style={styles.podiumAvatarText}>{currentLeaders[2]?.avatar}</Text>
              </View>
              <View style={[styles.podiumBar, styles.thirdBar]} />
              <Text style={styles.podiumRank}>3</Text>
              <Text style={styles.podiumName}>{currentLeaders[2]?.name.split(' ')[0]}</Text>
              <Text style={styles.podiumKg}>{currentLeaders[2]?.kg} kg</Text>
            </View>
          </View>
        </View>

        {/* Full Leaderboard */}
        <View style={styles.leaderboardSection}>
          <Text style={styles.sectionTitle}>All Rankings</Text>
          {currentLeaders.map((leader, index) => (
            <LeaderboardCard
              key={leader.id}
              rank={leader.rank}
              name={leader.name}
              avatar={leader.avatar}
              kg={leader.kg}
              items={leader.items}
              location={leader.location}
              isCurrentUser={leader.isCurrentUser}
              showTrend={index < 3}
            />
          ))}
        </View>

        {/* Stats Summary */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>Community Impact</Text>
          <View style={styles.statsSummary}>
            <View style={styles.statItem}>
              <TrendingUp size={24} color="#22C55E" />
              <Text style={styles.statValue}>2,847 kg</Text>
              <Text style={styles.statLabel}>Total Recycled</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Award size={24} color="#10B981" />
              <Text style={styles.statValue}>10,247</Text>
              <Text style={styles.statLabel}>Active Users</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Medal size={24} color="#059669" />
              <Text style={styles.statValue}>156</Text>
              <Text style={styles.statLabel}>Cities</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 20,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#E5E7EB',
    borderRadius: 12,
    padding: 4,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    gap: 6,
  },
  activeTab: {
    backgroundColor: '#22C55E',
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  scrollContent: {
    paddingBottom: 20,
  },
  podiumSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  podium: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  podiumPlace: {
    alignItems: 'center',
    marginHorizontal: 12,
  },
  crownContainer: {
    position: 'absolute',
    top: -30,
    zIndex: 1,
  },
  podiumAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    borderWidth: 3,
  },
  firstPlace: {
    backgroundColor: '#FEF3C7',
    borderColor: '#FFD700',
  },
  secondPlace: {
    backgroundColor: '#E5E7EB',
    borderColor: '#9CA3AF',
  },
  thirdPlace: {
    backgroundColor: '#FED7AA',
    borderColor: '#FB923C',
  },
  podiumAvatarText: {
    fontSize: 24,
  },
  podiumBar: {
    width: 60,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    marginBottom: 8,
  },
  firstBar: {
    height: 80,
    backgroundColor: '#22C55E',
  },
  secondBar: {
    height: 60,
    backgroundColor: '#10B981',
  },
  thirdBar: {
    height: 40,
    backgroundColor: '#059669',
  },
  podiumRank: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  podiumName: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  podiumKg: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  leaderboardSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  statsSection: {
    paddingHorizontal: 20,
  },
  statsSummary: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    textAlign: 'center',
  },
  statDivider: {
    width: 1,
    height: 40,
    backgroundColor: '#E5E7EB',
    marginHorizontal: 16,
  },
});