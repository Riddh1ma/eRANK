import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MapPin, Navigation, Filter, Search } from 'lucide-react-native';
import { BinMapCard } from '@/components/BinMapCard';
import { useState } from 'react';

export default function Map() {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'available' | 'full' | 'nearby'>('all');

  const bins = [
    {
      id: 'BIN_SF_001',
      name: 'Tech Campus Building A',
      address: '123 Innovation Drive',
      distance: '0.2 km',
      fillLevel: 95,
      status: 'full',
      type: 'Electronics',
      coordinates: { lat: 37.7749, lng: -122.4194 },
    },
    {
      id: 'BIN_SF_002',
      name: 'Downtown Library',
      address: '456 Main Street',
      distance: '0.5 km',
      fillLevel: 45,
      status: 'available',
      type: 'Mixed E-Waste',
      coordinates: { lat: 37.7849, lng: -122.4094 },
    },
    {
      id: 'BIN_SF_003',
      name: 'University Campus',
      address: '789 College Ave',
      distance: '0.8 km',
      fillLevel: 78,
      status: 'available',
      type: 'Electronics',
      coordinates: { lat: 37.7649, lng: -122.4294 },
    },
    {
      id: 'BIN_SF_004',
      name: 'Shopping Mall',
      address: '321 Retail Plaza',
      distance: '1.2 km',
      fillLevel: 25,
      status: 'available',
      type: 'Batteries & Small Items',
      coordinates: { lat: 37.7549, lng: -122.4394 },
    },
    {
      id: 'BIN_SF_005',
      name: 'Business District',
      address: '654 Corporate Blvd',
      distance: '1.5 km',
      fillLevel: 88,
      status: 'full',
      type: 'Mixed E-Waste',
      coordinates: { lat: 37.7949, lng: -122.3994 },
    },
  ];

  const filters = [
    { key: 'all', label: 'All Bins', count: bins.length },
    { key: 'available', label: 'Available', count: bins.filter(b => b.status === 'available').length },
    { key: 'full', label: 'Full', count: bins.filter(b => b.status === 'full').length },
    { key: 'nearby', label: 'Nearby', count: bins.filter(b => parseFloat(b.distance) < 1).length },
  ] as const;

  const filteredBins = bins.filter(bin => {
    switch (selectedFilter) {
      case 'available': return bin.status === 'available';
      case 'full': return bin.status === 'full';
      case 'nearby': return parseFloat(bin.distance) < 1;
      default: return true;
    }
  });

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Collection Bins</Text>
        <Text style={styles.subtitle}>Find nearby e-waste collection points</Text>
      </View>

      {/* Map Placeholder */}
      <View style={styles.mapContainer}>
        <View style={styles.mapPlaceholder}>
          <MapPin size={48} color="#22C55E" />
          <Text style={styles.mapText}>Interactive Map</Text>
          <Text style={styles.mapSubtext}>Web map view coming soon</Text>
        </View>
        <TouchableOpacity style={styles.locationButton}>
          <Navigation size={20} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      {/* Filter Section */}
      <View style={styles.filterSection}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterList}>
          {filters.map((filter) => (
            <TouchableOpacity
              key={filter.key}
              style={[
                styles.filterButton,
                selectedFilter === filter.key && styles.activeFilterButton
              ]}
              onPress={() => setSelectedFilter(filter.key)}
            >
              <Text style={[
                styles.filterText,
                selectedFilter === filter.key && styles.activeFilterText
              ]}>
                {filter.label} ({filter.count})
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Bin List */}
      <ScrollView style={styles.binList} showsVerticalScrollIndicator={false} contentContainerStyle={styles.binListContent}>
        <View style={styles.binListHeader}>
          <Text style={styles.sectionTitle}>
            {selectedFilter === 'all' ? 'All Collection Bins' : 
             selectedFilter === 'available' ? 'Available Bins' :
             selectedFilter === 'full' ? 'Full Bins' : 'Nearby Bins'}
          </Text>
          <Text style={styles.binCount}>{filteredBins.length} bins</Text>
        </View>

        {filteredBins.map((bin) => (
          <BinMapCard key={bin.id} bin={bin} />
        ))}

        {/* Legend */}
        <View style={styles.legend}>
          <Text style={styles.legendTitle}>Legend</Text>
          <View style={styles.legendItems}>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#22C55E' }]} />
              <Text style={styles.legendText}>Available (0-80% full)</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#F59E0B' }]} />
              <Text style={styles.legendText}>Nearly Full (80-95% full)</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: '#EF4444' }]} />
              <Text style={styles.legendText}>Full (95%+ full)</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  mapContainer: {
    height: 200,
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 16,
    overflow: 'hidden',
    position: 'relative',
  },
  mapPlaceholder: {
    flex: 1,
    backgroundColor: '#E5E7EB',
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#374151',
    marginTop: 12,
  },
  mapSubtext: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 4,
  },
  locationButton: {
    position: 'absolute',
    bottom: 16,
    right: 16,
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#22C55E',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  filterSection: {
    marginBottom: 20,
  },
  filterList: {
    paddingHorizontal: 20,
    gap: 8,
  },
  filterButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  activeFilterButton: {
    backgroundColor: '#22C55E',
    borderColor: '#22C55E',
  },
  filterText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  activeFilterText: {
    color: '#FFFFFF',
  },
  binList: {
    flex: 1,
  },
  binListContent: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  binListHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  binCount: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  legend: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginTop: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  legendTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 12,
  },
  legendItems: {
    gap: 8,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  legendDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  legendText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
});