import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState } from 'react';
import { Truck, MapPin, Calendar, Clock, TriangleAlert as AlertTriangle, CircleCheck as CheckCircle, Phone } from 'lucide-react-native';
import { PickupRequestCard } from '@/components/PickupRequestCard';

export default function Pickup() {
  const [selectedBin, setSelectedBin] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');

  const fullBins = [
    {
      id: 'BIN_SF_001',
      location: 'Tech Campus Building A',
      address: '123 Innovation Drive, San Francisco',
      fillLevel: 95,
      lastEmpty: '3 days ago',
      status: 'urgent',
    },
    {
      id: 'BIN_SF_002',
      location: 'Downtown Library',
      address: '456 Main Street, San Francisco',
      fillLevel: 82,
      lastEmpty: '2 days ago',
      status: 'attention',
    },
    {
      id: 'BIN_SF_003',
      location: 'University Campus',
      address: '789 College Ave, San Francisco',
      fillLevel: 78,
      lastEmpty: '1 day ago',
      status: 'moderate',
    },
  ];

  const recentRequests = [
    {
      id: '1',
      binId: 'BIN_SF_004',
      location: 'Shopping Mall',
      requestDate: '2025-01-07',
      status: 'completed',
      estimatedDate: '2025-01-08',
    },
    {
      id: '2',
      binId: 'BIN_SF_005',
      location: 'Business District',
      requestDate: '2025-01-06',
      status: 'scheduled',
      estimatedDate: '2025-01-09',
    },
  ];

  const handleSchedulePickup = () => {
    if (!selectedBin || !selectedDate || !selectedTime) {
      Alert.alert('Missing Information', 'Please fill in all required fields.');
      return;
    }

    Alert.alert(
      'Pickup Scheduled',
      `Your pickup request for ${selectedBin} has been submitted successfully. You will receive a confirmation shortly.`,
      [
        {
          text: 'OK',
          onPress: () => {
            setSelectedBin('');
            setLocation('');
            setDescription('');
            setSelectedDate('');
            setSelectedTime('');
          }
        }
      ]
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'urgent': return '#EF4444';
      case 'attention': return '#F59E0B';
      case 'moderate': return '#10B981';
      default: return '#6B7280';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'urgent': return <AlertTriangle size={16} color="#EF4444" />;
      case 'attention': return <Clock size={16} color="#F59E0B" />;
      case 'moderate': return <CheckCircle size={16} color="#10B981" />;
      default: return null;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.title}>Pickup Requests</Text>
          <Text style={styles.subtitle}>Schedule pickups for full bins</Text>
        </View>

        {/* Full Bins Alert */}
        <View style={styles.alertSection}>
          <Text style={styles.sectionTitle}>Bins Needing Attention</Text>
          {fullBins.map((bin) => (
            <TouchableOpacity
              key={bin.id}
              style={[
                styles.binCard,
                selectedBin === bin.id && styles.selectedBinCard
              ]}
              onPress={() => {
                setSelectedBin(bin.id);
                setLocation(bin.location);
              }}
            >
              <View style={styles.binHeader}>
                <View style={styles.binInfo}>
                  <Text style={styles.binId}>{bin.id}</Text>
                  <Text style={styles.binLocation}>{bin.location}</Text>
                  <Text style={styles.binAddress}>{bin.address}</Text>
                </View>
                <View style={styles.binStatus}>
                  {getStatusIcon(bin.status)}
                  <Text style={[styles.fillLevel, { color: getStatusColor(bin.status) }]}>
                    {bin.fillLevel}% full
                  </Text>
                </View>
              </View>
              <View style={styles.binMeta}>
                <Text style={styles.lastEmpty}>Last emptied: {bin.lastEmpty}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Pickup Request Form */}
        <View style={styles.formSection}>
          <Text style={styles.sectionTitle}>Schedule Pickup</Text>
          <View style={styles.form}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Bin ID *</Text>
              <TextInput
                style={styles.input}
                value={selectedBin}
                onChangeText={setSelectedBin}
                placeholder="Enter bin ID or select from above"
                placeholderTextColor="#9CA3AF"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Location</Text>
              <TextInput
                style={styles.input}
                value={location}
                onChangeText={setLocation}
                placeholder="Bin location"
                placeholderTextColor="#9CA3AF"
              />
            </View>

            <View style={styles.inputRow}>
              <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
                <Text style={styles.label}>Preferred Date *</Text>
                <TouchableOpacity style={styles.dateInput}>
                  <Calendar size={20} color="#6B7280" />
                  <Text style={[styles.dateText, !selectedDate && styles.placeholder]}>
                    {selectedDate || 'Select date'}
                  </Text>
                </TouchableOpacity>
              </View>

              <View style={[styles.inputGroup, { flex: 1, marginLeft: 8 }]}>
                <Text style={styles.label}>Time Slot *</Text>
                <TouchableOpacity style={styles.dateInput}>
                  <Clock size={20} color="#6B7280" />
                  <Text style={[styles.dateText, !selectedTime && styles.placeholder]}>
                    {selectedTime || 'Select time'}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Additional Notes</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={description}
                onChangeText={setDescription}
                placeholder="Any additional information about the bin condition..."
                placeholderTextColor="#9CA3AF"
                multiline
                numberOfLines={3}
              />
            </View>

            <TouchableOpacity style={styles.scheduleButton} onPress={handleSchedulePickup}>
              <Truck size={20} color="#FFFFFF" />
              <Text style={styles.scheduleButtonText}>Schedule Pickup</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Recent Requests */}
        <View style={styles.historySection}>
          <Text style={styles.sectionTitle}>Recent Requests</Text>
          {recentRequests.map((request) => (
            <PickupRequestCard key={request.id} request={request} />
          ))}
        </View>

        {/* Emergency Contact */}
        <View style={styles.emergencySection}>
          <View style={styles.emergencyHeader}>
            <Phone size={24} color="#EF4444" />
            <Text style={styles.emergencyTitle}>Emergency Pickup</Text>
          </View>
          <Text style={styles.emergencyText}>
            For urgent pickup requests or overflowing bins, contact our 24/7 support line
          </Text>
          <TouchableOpacity style={styles.emergencyButton}>
            <Phone size={20} color="#EF4444" />
            <Text style={styles.emergencyButtonText}>Call Emergency Line</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scrollContent: {
    paddingBottom: 20,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  alertSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  binCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  selectedBinCard: {
    borderColor: '#22C55E',
    backgroundColor: '#F0FDF4',
  },
  binHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  binInfo: {
    flex: 1,
  },
  binId: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 2,
  },
  binLocation: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#374151',
    marginBottom: 2,
  },
  binAddress: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  binStatus: {
    alignItems: 'flex-end',
  },
  fillLevel: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    marginTop: 4,
  },
  binMeta: {
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
    paddingTop: 8,
  },
  lastEmpty: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  formSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  form: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputRow: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#374151',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
    backgroundColor: '#FFFFFF',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  dateInput: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
  },
  dateText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
    marginLeft: 8,
    flex: 1,
  },
  placeholder: {
    color: '#9CA3AF',
  },
  scheduleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#22C55E',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    gap: 8,
  },
  scheduleButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  historySection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  emergencySection: {
    marginHorizontal: 20,
    backgroundColor: '#FEF2F2',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#FECACA',
  },
  emergencyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  emergencyTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#DC2626',
    marginLeft: 8,
  },
  emergencyText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#7F1D1D',
    marginBottom: 16,
    lineHeight: 20,
  },
  emergencyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#EF4444',
    gap: 8,
  },
  emergencyButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#EF4444',
  },
});