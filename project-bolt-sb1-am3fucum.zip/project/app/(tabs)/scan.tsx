import { View, Text, StyleSheet, TouchableOpacity, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState } from 'react';
import { CameraView, CameraType, useCameraPermissions } from 'expo-camera';
import { QrCode, Upload, Camera, FlashlightOff as FlashOff, Slash as FlashOn, RotateCcw } from 'lucide-react-native';
import { ScanSuccessModal } from '@/components/ScanSuccessModal';

export default function Scan() {
  const [facing, setFacing] = useState<CameraType>('back');
  const [flashEnabled, setFlashEnabled] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [scannedData, setScannedData] = useState<any>(null);
  const [permission, requestPermission] = useCameraPermissions();

  const handleScanPress = async () => {
    if (Platform.OS === 'web') {
      // Web fallback - simulate scan
      Alert.alert(
        'Camera Not Available',
        'Camera scanning is not available on web. Would you like to simulate a successful scan?',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Simulate', 
            onPress: () => {
              const mockData = {
                binId: 'BIN_SF_001',
                location: 'Tech Campus Building A',
                type: 'Electronics',
                weight: 2.3,
                items: ['Smartphone', 'Laptop charger'],
              };
              setScannedData(mockData);
              setShowSuccess(true);
            }
          }
        ]
      );
      return;
    }

    if (!permission) {
      return;
    }

    if (!permission.granted) {
      const result = await requestPermission();
      if (!result.granted) {
        Alert.alert('Permission needed', 'Camera permission is required to scan QR codes');
        return;
      }
    }

    setShowCamera(true);
  };

  const handleBarcodeScanned = ({ data }: { data: string }) => {
    try {
      const scanData = JSON.parse(data);
      setScannedData(scanData);
      setShowCamera(false);
      setShowSuccess(true);
    } catch (error) {
      // If not JSON, treat as simple bin ID
      const mockData = {
        binId: data,
        location: 'Unknown Location',
        type: 'Electronics',
        weight: 1.5,
        items: ['Unknown item'],
      };
      setScannedData(mockData);
      setShowCamera(false);
      setShowSuccess(true);
    }
  };

  const handleManualUpload = () => {
    Alert.alert(
      'Manual Upload',
      'Select how you want to log your e-waste contribution:',
      [
        { text: 'Take Photo', onPress: () => handlePhotoUpload() },
        { text: 'Enter Details', onPress: () => handleManualEntry() },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const handlePhotoUpload = () => {
    // Simulate photo upload
    const mockData = {
      binId: 'MANUAL_ENTRY',
      location: 'Manual Upload',
      type: 'Electronics',
      weight: 3.2,
      items: ['Phone', 'Cables', 'Battery'],
    };
    setScannedData(mockData);
    setShowSuccess(true);
  };

  const handleManualEntry = () => {
    // Simulate manual entry
    const mockData = {
      binId: 'MANUAL_ENTRY',
      location: 'Home Collection',
      type: 'Mixed Electronics',
      weight: 1.8,
      items: ['Tablet', 'Headphones'],
    };
    setScannedData(mockData);
    setShowSuccess(true);
  };

  const toggleCameraFacing = () => {
    setFacing(current => (current === 'back' ? 'front' : 'back'));
  };

  const toggleFlash = () => {
    setFlashEnabled(current => !current);
  };

  if (showCamera) {
    return (
      <SafeAreaView style={styles.cameraContainer}>
        <CameraView
          style={styles.camera}
          facing={facing}
          onBarcodeScanned={handleBarcodeScanned}
          barcodeScannerSettings={{
            barcodeTypes: ['qr'],
          }}
        >
          <View style={styles.cameraOverlay}>
            <View style={styles.cameraHeader}>
              <TouchableOpacity
                style={styles.cameraButton}
                onPress={() => setShowCamera(false)}
              >
                <Text style={styles.cameraButtonText}>Cancel</Text>
              </TouchableOpacity>
              <Text style={styles.cameraTitle}>Scan QR Code</Text>
              <View style={styles.cameraControls}>
                <TouchableOpacity style={styles.controlButton} onPress={toggleFlash}>
                  {flashEnabled ? (
                    <FlashOn size={24} color="#FFFFFF" />
                  ) : (
                    <FlashOff size={24} color="#FFFFFF" />
                  )}
                </TouchableOpacity>
                <TouchableOpacity style={styles.controlButton} onPress={toggleCameraFacing}>
                  <RotateCcw size={24} color="#FFFFFF" />
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.scanArea}>
              <View style={styles.scanFrame} />
              <Text style={styles.scanInstructions}>
                Position the QR code within the frame
              </Text>
            </View>
          </View>
        </CameraView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Log E-Waste</Text>
        <Text style={styles.subtitle}>Scan QR codes or upload manually</Text>
      </View>

      <View style={styles.content}>
        {/* QR Scan Option */}
        <TouchableOpacity style={styles.scanOption} onPress={handleScanPress}>
          <View style={styles.scanIconContainer}>
            <QrCode size={48} color="#22C55E" />
          </View>
          <Text style={styles.scanTitle}>Scan QR Code</Text>
          <Text style={styles.scanDescription}>
            Scan the QR code on collection bins to instantly log your contribution
          </Text>
          <View style={styles.scanButton}>
            <Camera size={20} color="#FFFFFF" />
            <Text style={styles.scanButtonText}>Open Scanner</Text>
          </View>
        </TouchableOpacity>

        {/* Manual Upload Option */}
        <TouchableOpacity style={styles.uploadOption} onPress={handleManualUpload}>
          <View style={styles.uploadIconContainer}>
            <Upload size={48} color="#10B981" />
          </View>
          <Text style={styles.uploadTitle}>Manual Upload</Text>
          <Text style={styles.uploadDescription}>
            Take a photo or enter details manually for items not dropped at bins
          </Text>
          <View style={styles.uploadButton}>
            <Upload size={20} color="#10B981" />
            <Text style={styles.uploadButtonText}>Upload Now</Text>
          </View>
        </TouchableOpacity>

        {/* Recent Activity */}
        <View style={styles.recentSection}>
          <Text style={styles.recentTitle}>Recent Contributions</Text>
          <View style={styles.recentItem}>
            <View style={styles.recentIcon}>
              <Text style={styles.recentEmoji}>📱</Text>
            </View>
            <View style={styles.recentDetails}>
              <Text style={styles.recentItemText}>Smartphone & Charger</Text>
              <Text style={styles.recentLocation}>Tech Campus - Bin SF_001</Text>
              <Text style={styles.recentTime}>2 hours ago • 1.2 kg</Text>
            </View>
            <Text style={styles.recentPoints}>+12 pts</Text>
          </View>
          
          <View style={styles.recentItem}>
            <View style={styles.recentIcon}>
              <Text style={styles.recentEmoji}>💻</Text>
            </View>
            <View style={styles.recentDetails}>
              <Text style={styles.recentItemText}>Old Laptop</Text>
              <Text style={styles.recentLocation}>Home Collection</Text>
              <Text style={styles.recentTime}>Yesterday • 2.8 kg</Text>
            </View>
            <Text style={styles.recentPoints}>+28 pts</Text>
          </View>
        </View>
      </View>

      <ScanSuccessModal
        visible={showSuccess}
        onClose={() => setShowSuccess(false)}
        data={scannedData}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  scanOption: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  scanIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#F0FDF4',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  scanTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  scanDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  scanButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#22C55E',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    gap: 8,
  },
  scanButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  uploadOption: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 32,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  uploadIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#ECFDF5',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  uploadTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  uploadDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  uploadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#10B981',
    gap: 8,
  },
  uploadButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#10B981',
  },
  recentSection: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  recentTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  recentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  recentIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  recentEmoji: {
    fontSize: 20,
  },
  recentDetails: {
    flex: 1,
  },
  recentItemText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  recentLocation: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 2,
  },
  recentTime: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  recentPoints: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#22C55E',
  },
  cameraContainer: {
    flex: 1,
    backgroundColor: '#000000',
  },
  camera: {
    flex: 1,
  },
  cameraOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },
  cameraHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
  },
  cameraButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
  },
  cameraButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
  },
  cameraTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  cameraControls: {
    flexDirection: 'row',
    gap: 12,
  },
  controlButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanArea: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanFrame: {
    width: 250,
    height: 250,
    borderWidth: 3,
    borderColor: '#22C55E',
    borderRadius: 20,
    backgroundColor: 'transparent',
    marginBottom: 32,
  },
  scanInstructions: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
    textAlign: 'center',
    paddingHorizontal: 40,
  },
});