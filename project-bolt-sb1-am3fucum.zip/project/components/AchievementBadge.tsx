import { View, Text, StyleSheet } from 'react-native';

interface AchievementBadgeProps {
  name: string;
  icon: string;
  unlocked: boolean;
}

export function AchievementBadge({ name, icon, unlocked }: AchievementBadgeProps) {
  return (
    <View style={[styles.container, !unlocked && styles.locked]}>
      <View style={[styles.iconContainer, !unlocked && styles.lockedIcon]}>
        <Text style={[styles.icon, !unlocked && styles.lockedIconText]}>{icon}</Text>
      </View>
      <Text style={[styles.name, !unlocked && styles.lockedText]}>{name}</Text>
      {unlocked && <View style={styles.checkmark}>
        <Text style={styles.checkmarkText}>✓</Text>
      </View>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    minWidth: 100,
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  locked: {
    backgroundColor: '#F9FAFB',
    opacity: 0.6,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F0FDF4',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  lockedIcon: {
    backgroundColor: '#F3F4F6',
  },
  icon: {
    fontSize: 24,
  },
  lockedIconText: {
    opacity: 0.5,
  },
  name: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    textAlign: 'center',
  },
  lockedText: {
    color: '#9CA3AF',
  },
  checkmark: {
    position: 'absolute',
    top: -4,
    right: -4,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#22C55E',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkmarkText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontFamily: 'Inter-Bold',
  },
});