import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MapPin, Navigation, Truck, Battery } from 'lucide-react-native';

interface Bin {
  id: string;
  name: string;
  address: string;
  distance: string;
  fillLevel: number;
  status: 'available' | 'full';
  type: string;
  coordinates: { lat: number; lng: number };
}

interface BinMapCardProps {
  bin: Bin;
}

export function BinMapCard({ bin }: BinMapCardProps) {
  const getStatusColor = () => {
    if (bin.fillLevel >= 95) return '#EF4444';
    if (bin.fillLevel >= 80) return '#F59E0B';
    return '#22C55E';
  };

  const getTypeIcon = () => {
    switch (bin.type.toLowerCase()) {
      case 'batteries & small items':
        return <Battery size={20} color="#6B7280" />;
      default:
        return <Truck size={20} color="#6B7280" />;
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.binInfo}>
          <Text style={styles.name}>{bin.name}</Text>
          <View style={styles.addressContainer}>
            <MapPin size={14} color="#6B7280" />
            <Text style={styles.address}>{bin.address}</Text>
          </View>
          <View style={styles.typeContainer}>
            {getTypeIcon()}
            <Text style={styles.type}>{bin.type}</Text>
          </View>
        </View>
        <View style={styles.rightSection}>
          <Text style={styles.distance}>{bin.distance}</Text>
          <View style={[styles.statusDot, { backgroundColor: getStatusColor() }]} />
        </View>
      </View>

      <View style={styles.footer}>
        <View style={styles.fillContainer}>
          <Text style={styles.fillLabel}>Fill Level</Text>
          <View style={styles.fillBar}>
            <View 
              style={[
                styles.fillProgress, 
                { 
                  width: `${bin.fillLevel}%`, 
                  backgroundColor: getStatusColor() 
                }
              ]} 
            />
          </View>
          <Text style={[styles.fillText, { color: getStatusColor() }]}>
            {bin.fillLevel}%
          </Text>
        </View>
        <TouchableOpacity style={styles.directionsButton}>
          <Navigation size={16} color="#22C55E" />
          <Text style={styles.directionsText}>Directions</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  binInfo: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  addressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 6,
  },
  address: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  typeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  type: {
    fontSize: 13,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  rightSection: {
    alignItems: 'flex-end',
  },
  distance: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 8,
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  fillContainer: {
    flex: 1,
    marginRight: 16,
  },
  fillLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  fillBar: {
    height: 6,
    backgroundColor: '#E5E7EB',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 4,
  },
  fillProgress: {
    height: '100%',
    borderRadius: 3,
  },
  fillText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  directionsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#F0FDF4',
    borderRadius: 8,
    gap: 4,
  },
  directionsText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#22C55E',
  },
});