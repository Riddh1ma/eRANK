import { View, Text, StyleSheet } from 'react-native';
import { Lightbulb } from 'lucide-react-native';

const tips = [
  "Remove batteries from devices before recycling to prevent environmental damage.",
  "Old smartphones contain precious metals like gold and silver that can be recovered.",
  "One recycled laptop can save the energy equivalent to powering a home for 3.5 days.",
  "E-waste is the fastest-growing waste stream globally - every contribution counts!",
  "Properly recycling your old phone can recover enough materials to make a new one.",
];

export function DailyTip() {
  const todaysTip = tips[new Date().getDate() % tips.length];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.iconContainer}>
          <Lightbulb size={20} color="#F59E0B" />
        </View>
        <Text style={styles.title}>Daily Eco Tip</Text>
      </View>
      <Text style={styles.tip}>{todaysTip}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 20,
    backgroundColor: '#FFFBEB',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FEF3C7',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  title: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#92400E',
  },
  tip: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#78350F',
    lineHeight: 20,
  },
});