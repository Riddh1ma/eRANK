import { View, Text, StyleSheet } from 'react-native';
import { TrendingUp, MapPin } from 'lucide-react-native';

interface LeaderboardCardProps {
  rank: number;
  name: string;
  avatar: string;
  kg: number;
  items: number;
  location: string;
  isCurrentUser?: boolean;
  showTrend?: boolean;
}

export function LeaderboardCard({ 
  rank, 
  name, 
  avatar, 
  kg, 
  items, 
  location, 
  isCurrentUser, 
  showTrend 
}: LeaderboardCardProps) {
  const getRankStyle = () => {
    if (rank === 1) return styles.firstRank;
    if (rank === 2) return styles.secondRank;
    if (rank === 3) return styles.thirdRank;
    return styles.defaultRank;
  };

  const getRankColor = () => {
    if (rank === 1) return '#FFD700';
    if (rank === 2) return '#C0C0C0';
    if (rank === 3) return '#CD7F32';
    return '#6B7280';
  };

  return (
    <View style={[styles.container, isCurrentUser && styles.currentUserCard]}>
      <View style={styles.leftSection}>
        <View style={[styles.rankBadge, getRankStyle()]}>
          <Text style={[styles.rankText, { color: getRankColor() }]}>#{rank}</Text>
        </View>
        <View style={styles.avatarContainer}>
          <Text style={styles.avatar}>{avatar}</Text>
        </View>
        <View style={styles.userInfo}>
          <Text style={[styles.name, isCurrentUser && styles.currentUserName]}>
            {name}
            {isCurrentUser && ' (You)'}
          </Text>
          <View style={styles.locationContainer}>
            <MapPin size={12} color="#6B7280" />
            <Text style={styles.location}>{location}</Text>
          </View>
        </View>
      </View>

      <View style={styles.rightSection}>
        <View style={styles.stats}>
          <Text style={styles.kgValue}>{kg} kg</Text>
          <Text style={styles.itemsValue}>{items} items</Text>
        </View>
        {showTrend && (
          <View style={styles.trendContainer}>
            <TrendingUp size={16} color="#22C55E" />
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  currentUserCard: {
    backgroundColor: '#F0FDF4',
    borderWidth: 2,
    borderColor: '#22C55E',
  },
  leftSection: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  rankBadge: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  firstRank: {
    backgroundColor: '#FEF3C7',
  },
  secondRank: {
    backgroundColor: '#E5E7EB',
  },
  thirdRank: {
    backgroundColor: '#FED7AA',
  },
  defaultRank: {
    backgroundColor: '#F3F4F6',
  },
  rankText: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
  },
  avatarContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#E0F2FE',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  avatar: {
    fontSize: 20,
  },
  userInfo: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  currentUserName: {
    color: '#22C55E',
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  location: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  rightSection: {
    alignItems: 'flex-end',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  stats: {
    alignItems: 'flex-end',
  },
  kgValue: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  itemsValue: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  trendContainer: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#F0FDF4',
    alignItems: 'center',
    justifyContent: 'center',
  },
});