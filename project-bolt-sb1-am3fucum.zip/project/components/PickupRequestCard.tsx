import { View, Text, StyleSheet } from 'react-native';
import { Calendar, MapPin, CircleCheck as CheckCircle, Clock, Truck } from 'lucide-react-native';

interface PickupRequest {
  id: string;
  binId: string;
  location: string;
  requestDate: string;
  status: 'pending' | 'scheduled' | 'completed' | 'cancelled';
  estimatedDate: string;
}

interface PickupRequestCardProps {
  request: PickupRequest;
}

export function PickupRequestCard({ request }: PickupRequestCardProps) {
  const getStatusStyle = () => {
    switch (request.status) {
      case 'completed':
        return { backgroundColor: '#F0FDF4', borderColor: '#22C55E', color: '#15803D' };
      case 'scheduled':
        return { backgroundColor: '#FEF3C7', borderColor: '#F59E0B', color: '#92400E' };
      case 'pending':
        return { backgroundColor: '#EFF6FF', borderColor: '#3B82F6', color: '#1D4ED8' };
      default:
        return { backgroundColor: '#FEF2F2', borderColor: '#EF4444', color: '#DC2626' };
    }
  };

  const getStatusIcon = () => {
    switch (request.status) {
      case 'completed':
        return <CheckCircle size={16} color="#22C55E" />;
      case 'scheduled':
        return <Truck size={16} color="#F59E0B" />;
      case 'pending':
        return <Clock size={16} color="#3B82F6" />;
      default:
        return null;
    }
  };

  const statusStyle = getStatusStyle();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.binInfo}>
          <Text style={styles.binId}>{request.binId}</Text>
          <View style={styles.locationContainer}>
            <MapPin size={14} color="#6B7280" />
            <Text style={styles.location}>{request.location}</Text>
          </View>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: statusStyle.backgroundColor, borderColor: statusStyle.borderColor }]}>
          {getStatusIcon()}
          <Text style={[styles.statusText, { color: statusStyle.color }]}>
            {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
          </Text>
        </View>
      </View>

      <View style={styles.dates}>
        <View style={styles.dateItem}>
          <Calendar size={16} color="#6B7280" />
          <Text style={styles.dateLabel}>Requested:</Text>
          <Text style={styles.dateValue}>{new Date(request.requestDate).toLocaleDateString()}</Text>
        </View>
        {request.estimatedDate && (
          <View style={styles.dateItem}>
            <Truck size={16} color="#6B7280" />
            <Text style={styles.dateLabel}>Estimated:</Text>
            <Text style={styles.dateValue}>{new Date(request.estimatedDate).toLocaleDateString()}</Text>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  binInfo: {
    flex: 1,
  },
  binId: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  location: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    borderWidth: 1,
    gap: 4,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  dates: {
    gap: 8,
  },
  dateItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  dateLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  dateValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
});