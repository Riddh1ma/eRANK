import { View, Text, StyleSheet, Modal, TouchableOpacity, ScrollView } from 'react-native';
import { CircleCheck as CheckCircle, X, MapPin, Scale, Package, Award } from 'lucide-react-native';

interface ScanSuccessModalProps {
  visible: boolean;
  onClose: () => void;
  data: any;
}

export function ScanSuccessModal({ visible, onClose, data }: ScanSuccessModalProps) {
  if (!data) return null;

  const points = Math.floor(data.weight * 10);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <TouchableOpacity style={styles.closeButton} onPress={onClose}>
            <X size={24} color="#6B7280" />
          </TouchableOpacity>

          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
            {/* Success Header */}
            <View style={styles.header}>
              <View style={styles.successIcon}>
                <CheckCircle size={48} color="#22C55E" />
              </View>
              <Text style={styles.title}>Contribution Logged!</Text>
              <Text style={styles.subtitle}>
                Your e-waste has been successfully recorded
              </Text>
            </View>

            {/* Points Earned */}
            <View style={styles.pointsSection}>
              <View style={styles.pointsIcon}>
                <Award size={24} color="#F59E0B" />
              </View>
              <Text style={styles.pointsText}>+{points} Points Earned</Text>
            </View>

            {/* Contribution Details */}
            <View style={styles.detailsSection}>
              <Text style={styles.detailsTitle}>Contribution Details</Text>
              
              <View style={styles.detailItem}>
                <View style={styles.detailIcon}>
                  <MapPin size={20} color="#6B7280" />
                </View>
                <View style={styles.detailContent}>
                  <Text style={styles.detailLabel}>Location</Text>
                  <Text style={styles.detailValue}>{data.location}</Text>
                </View>
              </View>

              <View style={styles.detailItem}>
                <View style={styles.detailIcon}>
                  <Scale size={20} color="#6B7280" />
                </View>
                <View style={styles.detailContent}>
                  <Text style={styles.detailLabel}>Weight</Text>
                  <Text style={styles.detailValue}>{data.weight} kg</Text>
                </View>
              </View>

              <View style={styles.detailItem}>
                <View style={styles.detailIcon}>
                  <Package size={20} color="#6B7280" />
                </View>
                <View style={styles.detailContent}>
                  <Text style={styles.detailLabel}>Items</Text>
                  <Text style={styles.detailValue}>{data.items.join(', ')}</Text>
                </View>
              </View>
            </View>

            {/* Environmental Impact */}
            <View style={styles.impactSection}>
              <Text style={styles.impactTitle}>Environmental Impact</Text>
              <View style={styles.impactGrid}>
                <View style={styles.impactItem}>
                  <Text style={styles.impactValue}>🌱</Text>
                  <Text style={styles.impactLabel}>CO₂ Saved</Text>
                  <Text style={styles.impactAmount}>{(data.weight * 2.3).toFixed(1)} kg</Text>
                </View>
                <View style={styles.impactItem}>
                  <Text style={styles.impactValue}>💧</Text>
                  <Text style={styles.impactLabel}>Water Saved</Text>
                  <Text style={styles.impactAmount}>{(data.weight * 15).toFixed(0)} L</Text>
                </View>
                <View style={styles.impactItem}>
                  <Text style={styles.impactValue}>⚡</Text>
                  <Text style={styles.impactLabel}>Energy Saved</Text>
                  <Text style={styles.impactAmount}>{(data.weight * 12).toFixed(0)} kWh</Text>
                </View>
              </View>
            </View>

            {/* Action Button */}
            <TouchableOpacity style={styles.actionButton} onPress={onClose}>
              <Text style={styles.actionButtonText}>Continue</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modal: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '80%',
    minHeight: '50%',
  },
  closeButton: {
    position: 'absolute',
    top: 20,
    right: 20,
    zIndex: 1,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    padding: 24,
    paddingTop: 32,
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
  },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#F0FDF4',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
  },
  pointsSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFBEB',
    borderRadius: 16,
    padding: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  pointsIcon: {
    marginRight: 8,
  },
  pointsText: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#92400E',
  },
  detailsSection: {
    marginBottom: 24,
  },
  detailsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  detailIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F9FAFB',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  detailContent: {
    flex: 1,
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  impactSection: {
    marginBottom: 32,
  },
  impactTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  impactGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  impactItem: {
    flex: 1,
    backgroundColor: '#F0FDF4',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  impactValue: {
    fontSize: 24,
    marginBottom: 8,
  },
  impactLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#059669',
    marginBottom: 4,
    textAlign: 'center',
  },
  impactAmount: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#047857',
  },
  actionButton: {
    backgroundColor: '#22C55E',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
  },
  actionButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});